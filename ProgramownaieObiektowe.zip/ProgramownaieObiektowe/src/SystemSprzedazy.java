import java.util.ArrayList;

public class SystemSprzedazy {
    public String oferta;
    private ArrayList<Transakcja> historiaTransakcji;       // powiazanie z transakcjami
    private ArrayList<String> id_klientow;                  // powiazanie z klientami

    public void obslugaTranskacji() {

    }

    public void odnotowanieZaplaty() {

    }
}
