public class Platnosc {
    public String czasSMS;
    public int nrPlatnosci;
    public float kwota;
    public int idPlatnosci;

    public void dodajPlatnosc() {

    }

    public String zestawienie() {
        return "";
    }
}
