public class Transakcja {
    public int idTransakcji;
    public int idPlatnosci;         // powizanie z Platnoscia
    public float kwotaTransakcji;
    public Klient klient;
    public String szczegolyTransakcji;

    public void rejestracjaTransakcji() {

    }

    public void odnotowanieZaplaty() {

    }
}
