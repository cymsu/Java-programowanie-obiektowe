import java.util.ArrayList;

public class Klient {
    public int idKlienta;
    public String daneOsobowe;
    public String kontakt;
    public String nrKomorki;
    private ArrayList<Transakcja> dokonaneTransakcje;       // powiazanie z Transkacjami
    private SystemRozliczen systemRozliczen;

    public boolean InformujOSukcesieLubPorazce() {
        return true;
    }
}
