import java.util.List;

public class SystemRozliczen {
    public String informacjeOSystemachSprzedazy;
    public List<Platnosc> rejestrPlatnosci;     // powiazanie z Platnosci

    public void przyjecieSMS() {

    }

    public void odnotowanieZaplaty() {

    }

    public void potwierdzenieDoSystemuSprzedazy() {

    }

    public void SMSZPotwierdzeniem() {

    }
}
