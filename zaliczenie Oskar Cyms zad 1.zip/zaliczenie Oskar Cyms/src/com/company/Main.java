package com.company;

public class Main {

    public static void main(String[] args) {
        Lampa lampa1 = new Lampa();
        Lampa lampa2 = new Lampa();

        lampa1.wlacz();
        lampa1.wypisz();

        lampa2.wlacz();
        lampa2.wypisz();
        lampa2.wylacz();
        lampa2.wypisz();

    }
}
