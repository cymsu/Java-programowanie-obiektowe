package com.company;

public class Lampa {
    private boolean czySwieci;
    public Lampa(){
        czySwieci = false;

    }

    public void wypisz() {
        if(czySwieci == true) {
            System.out.println("Swieci");
        } else {
            System.out.println("Nie swieci");
        }
    }

    public void wlacz() {
        czySwieci = true;

    }

    public void wylacz() {
        czySwieci = false;
    }
}
